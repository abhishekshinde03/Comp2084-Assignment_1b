﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace House_Rental.Models
{
    public class User
    {
        [Key]
        public int User_id { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        [Required]
        [DisplayName("User Name:")]

        public string User_name { get; set; }
        [Column(TypeName = "varchar(50)")]
        [DisplayName("User Deposit:")]
        [Required(ErrorMessage = "Please eter the user Name")]
        public int User_deposit { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        [Required]
        [DisplayName("Owner Name:")]
        public string Owner_house { get; set; }
    }
}
